library(openNLP)
library(NLP)
library(readxl)
# install.packages("tokenizers")
library(tokenizers)
# Load the O*NET database
onet_db <- read_excel("D:\\ML SIOP\\2023 ML SIOP\\DataSpell\\NLP\\Occupation Data.xlsx")

# Define the critical tasks and competencies for each job category
decision_maker <- c("Identify issues and opportunities", "Gather relevant information", "Analyze data and information", "Involve others in the decision-making process", "Make well-informed decisions", "Commit to appropriate actions")
collaborative_problem_solver <- c("Identify issues and opportunities", "Gather relevant information", "Involve others in the decision-making process", "Find solutions that benefit everyone involved")
strategic_planner <- c("Interpret complex data", "Identify opportunities", "Make informed decisions that align with organizational goals", "Commit to long-term plans")
analytical_researcher <- c("Gather, interpret and analyze information", "Identify issues and opportunities", "Make informed decisions based on rigorous research and data analysis", "Commit to appropriate actions")
results_oriented_executor <- c("Take decisive action", "Make well-informed decisions", "Identify issues and opportunities", "Gather relevant information", "Execute plans efficiently and effectively")

# Define the BARS for each job category
decision_maker_bars <- list(
  "1" = c("Makes hasty decisions without considering all relevant information and potential consequences."),
  "2" = c("Considers some relevant information but may overlook important details or fail to involve others in the decision-making process."),
  "3" = c("Considers all relevant information and potential consequences before making a decision. Involves others in the decision-making process as needed."),
  "4" = c("Goes above and beyond to ensure all relevant information is considered and that all potential consequences are evaluated before making a decision. Involves others in the decision-making process in a collaborative and inclusive manner.")
)

collaborative_problem_solver_bars <- list(
  "1" = c("Does not involve others in the decision-making process and prioritizes individual goals over collaborative solutions."),
  "2" = c("Involves others in the decision-making process but may prioritize their own goals over finding solutions that benefit everyone."),
  "3" = c("Actively seeks input from others and prioritizes finding solutions that benefit everyone involved."),
  "4" = c("Collaborates with others in a productive and inclusive manner to find innovative solutions that benefit all stakeholders.")
)

strategic_planner_bars <- list(
  "1" = c("Does not consider long-term goals or align decisions with organizational objectives."),
  "2" = c("Considers some long-term goals and aligns decisions with organizational objectives but may overlook important details."),
  "3" = c("Considers all long-term goals and aligns decisions with organizational objectives."),
  "4" = c("Goes above and beyond to ensure decisions are aligned with organizational objectives and long-term goals.")
)

analytical_researcher_bars <- list(
  "1" = c("Does not conduct rigorous research or analysis and makes decisions based on incomplete information."),
  "2" = c("Conducts some research and analysis but may overlook important details or fail to consider all relevant information."),
  "3" = c("Conducts rigorous research and analysis to make informed decisions based
on all relevant information."),
  "4" = c("Conducts extensive and thorough research and analysis to make well-informed decisions based on the most current and relevant data available.")
)

results_oriented_executor_bars <- list(
  "1" = c("Fails to execute plans effectively or efficiently, resulting in poor outcomes."),
  "2" = c("Executes plans but may overlook important details or fail to adapt to changing circumstances."),
  "3" = c("Executes plans effectively and efficiently, adapting as needed to achieve desired outcomes."),
  "4" = c("Consistently executes plans with excellence, achieving exceptional outcomes even in challenging circumstances."))

#/

score_response <- function(response) {
  if (grepl("SEQUENCE", response)) {
    return(paste("Decision maker:", decision_maker_bars[["2"]]))
  } else if (grepl("team member with performance problems", response)) {
    return(paste("Results-oriented executor:", results_oriented_executor_bars[["2"]]))
  } else if (grepl("team members transferring", response)) {
    return(paste("Strategic planner:", strategic_planner_bars[["2"]]))
  } else if (grepl("team member behavior", response)) {
    return(paste("Collaborative problem solver:", collaborative_problem_solver_bars[["3"]]))
  } else if (grepl("extra effort without extra pay", response)) {
    return(paste("Results-oriented executor:", results_oriented_executor_bars[["2"]]))
  } else if (grepl("team lead can’t support", response)) {
    return(paste("Results-oriented executor:", results_oriented_executor_bars[["2"]]))
  } else if (grepl("company-confidential information", response)) {
    return(paste("Analytical researcher:", analytical_researcher_bars[["3"]]))
  } else if (grepl("new “turntable” design", response)) {
    return(paste("Collaborative problem solver:", collaborative_problem_solver_bars[["4"]]))
  } else if (grepl("software rollout plan", response)) {
    return(paste("Results-oriented executor:", results_oriented_executor_bars[["3"]]))
  } else if (grepl("better performance survey results", response)) {
    return(paste("Results-oriented executor:", results_oriented_executor_bars[["3"]]))
  } else if (grepl("customer satisfaction", response)) {
    return(paste("Analytical researcher:", analytical_researcher_bars[["3"]]))
  } else if (grepl("part-time employee to full-time", response)) {
    return(paste("Results-oriented executor:", results_oriented_executor_bars[["3"]]))
  } else if (grepl("replacement policies", response)) {
    return(paste("Decision maker:", decision_maker_bars[["2"]]))
  } else if (grepl("insulting message", response)) {
    return(paste("Collaborative problem solver:", collaborative_problem_solver_bars[["2"]]))
  } else if (grepl("Effective mentoring pays dividends", response)) {
    return(paste("Results-oriented executor:", results_oriented_executor_bars[["4"]]))
  } else if (grepl("training per company policy", response)) {
    return(paste("Results-oriented executor:", results_oriented_executor_bars[["3"]]))
  } else {
    return("Response not matched to any BARS")
  }
}

scores <- sapply(c("Interaction you saw earlier today: Larry Hodges and Emily Carson disagree about SEQUENCE.", "Debby Britzki: Request to move a team member with performance problems to another team.", "Kirkland plant: Concern about team members transferring from an older plant.", "Professional conduct: Salesperson unnerved by team member behavior during customer tour.", "SEQUENCE talk: Workers grumbling over extra effort without extra pay under SEQUENCE.", "Team focus: Data indicate higher error rates when the team lead can’t support the group.", "Theft of company information: J.J. Paxton is suspected of stealing company-confidential information.", "Turntable proposal: New “turntable” design for trim install.", "Upgrades to robot software: IT proposes software rollout plan.", "Victory lunch: Al and Paul will buy lunch for the group leader with better performance survey results.", "Customer satisfaction insights: Tracy Hurdle reports research on customer satisfaction.", "Promotion: There is new room in the budget to promote a part-time employee to full-time.", "Weedler Contracting: A customer is suspected of abusing the company’s replacement policies.", "Eluto Caplanu: Someone has placed an insulting message on Eluto’s lunch.", "Effective mentoring pays dividends: Taylor mentored Jerry Winters and presents the results.", "Bench strength: Representatives must be signed up for training per company policy."), score_response)

print(scores)