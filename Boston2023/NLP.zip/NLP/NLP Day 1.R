tdata <- "What is a giraffe?"
#install.packages("qdap")
library(qdap)
frequent_terms <- freq_terms(tdata,3)

#/
# install.packages("readr")
library(readr)

tweetE <- read_csv("D:\\ML SIOP\\2023 ML SIOP\\DataSpell\\NLP\\Data\\2011.csv")
str(tweetE)
nrow(tweetE)
tweets_text <- tweetE$tweet
str(tweets_text)

#/

# install.packages("tm")
library(tm)
tweets_source <- VectorSource(tweets_text)