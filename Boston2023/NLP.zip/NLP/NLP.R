tdata <- "What is a giraffe?"
install.packages("qdap")
library(qdap)
frequent_terms <- freq_terms(tdata,3)